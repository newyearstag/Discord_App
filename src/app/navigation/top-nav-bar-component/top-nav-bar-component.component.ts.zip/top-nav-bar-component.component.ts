import { Component } from '@angular/core';

@Component({
  selector: 'app-top-nav-bar-component',
  templateUrl: './top-nav-bar-component.component.html',
  styleUrls: ['./top-nav-bar-component.component.css']
})
export class TopNavBarComponentComponent {

}
